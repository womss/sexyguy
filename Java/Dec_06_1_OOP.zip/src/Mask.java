public class Mask {
	String name;
	String shop;
	int price;
	
	public void printInfo() {
//		name = "기좋마스크";
//		shop = "편의점";
//		price = 1500;
		System.out.println(name);
		System.out.println(shop);
		System.out.println(price);
	}
}
