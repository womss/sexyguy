
// 클래스명의 첫글자는 항상 대문자
public class Cafe {
	// 이 객체의 속성 : 멤버 변수(member variable, attribute, field
	String name; // 이것들이 cafe라는 클래스 , 객체의 속성
	String location;
	double distance;
}
