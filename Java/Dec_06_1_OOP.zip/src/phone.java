
public class phone {
	
	String model;
	String made;
	int Price;
	
	public void printinfo() {
		System.out.println(this.model);
		System.out.println(made);
		System.out.println(Price);
	}
	
	
	public void bell() {
	System.out.println(" 띠리링 ~ ");
}
	
	
}

