import java.util.Random;
import java.util.Scanner;

public class FMain4 {
	// 홀짝 (함수.ver)
	//홀인지 짝인지 입력
	//컴퓨터가 숫자 공개
	// 맞추면 맞췄다고 결과공개
	
	
	// 랜덤한 동전 갯수 가져오기
	public static int shakeCoin() {
		Random r = new Random();
		int coin = r.nextInt(10)+1;
		return coin;
		// return new Random.nextInt(10)+1;
	}
	// 질문 & 답 입력
	public static String askUserAns() {
		Scanner k= new Scanner(System.in);
		System.out.print("홀? 짝? : ");
		String userAns = k.next();
		return userAns;
		// system.out.print ("홀? 짝? : ");
		// return new Scanner (System.in).next();
	}
	// 동전 갯수가 홀수면 '홀', 짝수면 '짝'
	public static String getAnswer(int coin) {
		String answer = (coin %2 == 0) ? "짝" : "홀" ;
		return answer;
		// return (coin %2 == 0) ? "짝" : "홀" ;
	}
		
	
	// 비교해서 결과 내기 위한 함수
	public static String getResult(String useranser, String a) {
		String result = (useranser.equals(a)) ? "정답" : "땡";
		return result;
		// return (useranser.equals(a)) ? "정답" : "땡";
	}
	
	// 결과 출력 함수
	
	public static void printResult(int coin, String useranswer, String a, String r) {
		System.out.printf("동전은 %d개\n", coin);
		System.out.printf("내가 입력한 답 %d개\n", useranswer);
		System.out.printf("동전은 %d개\n", a);
		System.out.printf("동전은 %d개\n", r);
		
	}
	// 기능들 다 모아둔 함수
	public static void start() {
		int coin = shakeCoin();
		String userAns = askUserAns();
		String answer = getAnswer(coin);
		String result = getResult(userAns, answer);
		printResult(coin, userAns, answer, result);
		
	}
	
	
//	public static String bat () {
//		Scanner k = new Scanner(System.in);
//		System.out.println("홀 짝 게임을 시작합니다\n선택해 주세요 : 홀 짝");
//		String bat = k.next();
//		return bat;
//		
//		}
//	
//	public static int daice() {
//		Random r = new Random();
//		int n = r.nextInt(10)+1;
//		return n;
//		
//		
//	}
//	
//	public static String redaice(int daicenum) {
//		String redaice = (daicenum % 2 == 1 ? "홀" : "짝");
//		return redaice;
//		
//	}
//	
//	
//	public static String result(String redaice, String batw) {
//		String result = (redaice.equals(batw) ? "배팅에 성공하셨습니다": "배팅에 실패하셨습니다"	);
//		return result;
//	}
//	
//	
////	public static void resultResult(int daicenum, String batw, String redaice, String bb ) {
////		System.out.println("==================");
////		System.out.printf("주사위 결과 %d\n", daicenum);
////		System.out.printf("사용자 배팅 %d\n", batw);
////		System.out.printf("주사위 홀짝 %d\n", redaice);
////		System.out.printf("게 결과 %d\n", bb);
////		
////		System.out.println("==================");
//	
//	
	public static void main(String[] args) {
//		
//		int daicenum = daice();
//		String batw = bat();
//		String redaice = redaice(daicenum);
//		String result = result(redaice, batw);
//		System.out.printf("주사위 값은 : %d\n", daicenum);
//
//		System.out.println(result);
		
//		resultResult(daicenum,batw,redaice, bb );
	}
	
	
	
	
	}
	
	
	
	
	
	
	
	
	

