
public class OMain3 {
	public static void main(String[] args) {
		System.out.println("=== 각 자료형들의 기본값 ===");
//		내가
//		WhatisValue v = new WhatisValue();
//		v.stringValue = "\"\"";
//		v.intValue = 0;
//		v.doubleValue = 0.0;
//		v.WhatisValue();
//		System.out.println(v);
		WhatisValue wiv = new WhatisValue();
		wiv.printInfo();
		
		
		
		
	}
}
