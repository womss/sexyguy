import java.util.Scanner;

public class CMain4 {
	
	
	public static void grade() {
		Scanner k = new Scanner(System.in);
		System.out.print(" 계급 입력 : ");
		String jjam = k.next();
	}

	
	
	
	public static void main(String[] args) {
		// Scanner로 입력받을 것
		
		// "이병" 입력 => 눈치, 관등성명, 훈련, 잠
		// "일병" 입력 => 관등성명, 훈련, 잠
		// "상병" 입력 => 훈련, 잠
		// "병장" 입력 => 잠
		
	
	
	//강사님
//	switch (jjam) {
//	case "이병":
//		System.out.println("눈치");
//	case "일병":
//		System.out.println("관등성명");
//	case "상병":
//		System.out.println("훈련");	
//	case "병장":
//		System.out.println("잠");
//		break;
//
//	default:
//		System.out.println("민간인(진)");
//		break;
	
	
//	switch (jjam) {
//	case "이병":
//		System.out.println(" ==============================");
//		System.out.println("ㅣ해야하는 일 : 눈치, 관등성명, 훈련, 잠 ㅣ");
//		System.out.println(" ==============================");
//		break;
//	case "일병":
//		System.out.println(" =========================");
//		System.out.println("ㅣ해야하는 일 : 관등성명, 훈련, 잠ㅣ");
//		System.out.println(" =========================");
//		break;
//	case "상병":
//		System.out.println(" ==================");
//		System.out.println("ㅣ해야하는 일 : 훈련, 잠ㅣ");	
//		System.out.println(" ==================");
//		break;
//	case "병장":
//		System.out.println(" =============");
//		System.out.println("ㅣ해야하는 일 : 잠ㅣ");
//		System.out.println(" =============");
//		break;
//
//	default:
//		break;
	}
		
		
		
	}
	




















