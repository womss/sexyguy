import java.util.Scanner;

public class OMain4 {
	public static void main(String[] args) {
		
		
		Scanner k = new Scanner(System.in);
		
		// 이름을 입력 받을거에요
		// 그 이름이 '홍길동' 이랑 같은지 같으면 true / 틀리면 false
		
		System.out.print("이름 : ");
		String name = k.next();
		boolean w = name.equals("홍길동");
		System.out.println(w);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		System.out.print("이름을 입력하세요 : ");
//		String name =k.next();
//		System.out.println(name);
//		boolean b = (name == "홍길동");   
//		System.out.println(b);
		
		
		// ** String 같은지 비교
		// 대상의 값 자체를 비교하기 위해서
		// .equals()를 사용
//		boolean b2 = name.equals("홍길동");
//		System.out.println(b2);
		
		
//		System.out.print("이름을 입력하세요 : ");
//		String name =k.next();
//		boolean w = 홍길동
//		System.out.printf("동명이인 : %b", name, );
		
		
		
		
		
		
		
		
		
		
	}
}
