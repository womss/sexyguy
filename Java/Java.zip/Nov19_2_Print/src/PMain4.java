
public class PMain4 {
	// 명함 만들기
	//이름 / 나이 / 성별 / 키 / 사는 도시 / 별명
	public static void main(String[] args) throws InterruptedException {
		
		System.out.println("   --------------------------------------");
		System.out.println("  ㅣ\t\t\t       ----- \tㅣ");
		System.out.printf("  ㅣ이름\t : %s\n", "성민\tㅣ   ㅣ\t    ㅣ\tㅣ");
		System.out.printf("  ㅣ나이\t : %d살", 30);
			System.out.printf("\tㅣ   ㅣ\t    ㅣ\tㅣ\n");
		System.out.printf("  ㅣ성별\t : %s\n", "남자\tㅣ   ㅣ\t    ㅣ\tㅣ");
		System.out.printf("  ㅣ키\t : %.1f", 178.3);
			System.out.printf("\tㅣ     -----\tㅣ\n");
		System.out.printf("  ㅣ사는도시: %s\n", "서울\tㅣ\t\tㅣ");
		System.out.printf("  ㅣ별명\t : %s\n", "없음\tㅣ\t\tㅣ");
		System.out.println("  ㅣ\t\t\t\t\tㅣ");
		System.out.println("   --------------------------------------");
		
		Thread.sleep(10000);		
		
		
	}
}
