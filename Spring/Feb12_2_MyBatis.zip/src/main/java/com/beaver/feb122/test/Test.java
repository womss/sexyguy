package com.beaver.feb122.test;

import java.util.Date;

public class Test {
	private String s_subject;
	private Date s_date;
	
	public Test() {
		// TODO Auto-generated constructor stub
	}

	public Test(String s_subject, Date s_date) {
		super();
		this.s_subject = s_subject;
		this.s_date = s_date;
	}

	public String getS_subject() {
		return s_subject;
	}

	public void setS_subject(String s_subject) {
		this.s_subject = s_subject;
	}

	public Date getS_date() {
		return s_date;
	}

	public void setS_date(Date s_date) {
		this.s_date = s_date;
	}
	
	
	
}
